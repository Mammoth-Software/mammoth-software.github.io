<template>
  <!--====== ABOUT PART START ======-->

  <section id="about" class="about-area pb-130">
    <div class="about-laptop">
      <img data-aos="fade-right" data-aos-duration="1000" src="assets/images/about/loptop.svg" alt="Loptop">
    </div>
    <div class="container">
      <div class="row justify-content-end">
        <div class="col-lg-6">
          <div class="about-content">
            <div class="section-title">
              <h5 class="sub-title">WELCOME TO Biz CREATIVE AGENCY</h5>
              <h2 class="title">3 Steps To A Success Product Business.</h2>
            </div> <!-- section -title -->
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod temp or incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse is an ultrices gravida. Risus commodo. <br> <br> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod temp or incididunt ut labore.</p>
            <ul class="about-list">
              <li><i class="fa fa-check-circle"></i> Affordable pricing & billing Plans</li>
              <li><i class="fa fa-check-circle"></i> Built with amazing featues</li>
              <li><i class="fa fa-check-circle"></i> Easy to edit & User friendly design.</li>
              <li><i class="fa fa-check-circle"></i> Amazing framework with free plans</li>
            </ul>
          </div> <!-- about content -->
        </div>
      </div> <!-- row -->
    </div> <!-- container -->
    <div class="about-image">
      <div class="image animation1">
        <img src="assets/images/about/about.png" alt="about">
      </div>
    </div> <!-- about image -->
    <div class="about-man">
      <img data-aos="fade-right" data-aos-duration="1000" src="assets/images/about/man.svg" alt="Man">
    </div> <!-- aabout man -->
  </section>

  <!--====== ABOUT PART ENDS ======-->
</template>

<script>
    export default {
        name: "About"
    }
</script>

<style scoped>

</style>
