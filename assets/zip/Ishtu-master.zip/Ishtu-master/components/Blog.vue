<template>
  <!--====== BLOG PART START ======-->

  <section id="blog" class="blog-area gray-bg pt-125 pb-130">
    <div class="blog-man" data-aos="fade-right" data-aos-duration="1000">
      <img src="assets/images/svg/blog.png" alt="Man">
    </div>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6">
          <div class="section-title text-center pb-30">
            <h5 class="sub-title">Latest News</h5>
            <h2 class="title">Our Articles Latest News & Blog</h2>
          </div> <!-- section -title -->
        </div>
      </div> <!-- row -->
      <div class="row justify-content-center">
        <div class="col-lg-4 col-md-8 col-sm-9">
          <div class="single-blog mt-30">
            <div class="blog-content">
              <h4 class="blog-title"><a href="#">Edit when sober. Marketing is the hangover.</a></h4>
              <p>Lorem ipsum dolor sit amet, ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim.</p>
            </div>
            <div class="blog-meta mt-30 d-flex">
              <div class="blog-author">
                <img src="assets/images/blog/ba-1.jpg" alt="Addmin">
              </div>
              <div class="meta-title align-self-center">
                <h6 class="title">Posted by <a href="#">Mohammad</a></h6>
              </div>
            </div>
          </div> <!-- single blog -->
        </div>
        <div class="col-lg-4 col-md-8 col-sm-9">
          <div class="single-blog active mt-30">
            <div class="blog-content">
              <h4 class="blog-title"><a href="#">Edit when sober. Marketing is the hangover.</a></h4>
              <p>Lorem ipsum dolor sit amet, ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim.</p>
            </div>
            <div class="blog-meta mt-30 d-flex">
              <div class="blog-author">
                <img src="assets/images/blog/ba-1.jpg" alt="Addmin">
              </div>
              <div class="meta-title align-self-center">
                <h6 class="title">Posted by <a href="#">Mohammad</a></h6>
              </div>
            </div>
          </div> <!-- single blog -->
        </div>
        <div class="col-lg-4 col-md-8 col-sm-9">
          <div class="single-blog mt-30">
            <div class="blog-content">
              <h4 class="blog-title"><a href="#">Edit when sober. Marketing is the hangover.</a></h4>
              <p>Lorem ipsum dolor sit amet, ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim.</p>
            </div>
            <div class="blog-meta mt-30 d-flex">
              <div class="blog-author">
                <img src="assets/images/blog/ba-1.jpg" alt="Addmin">
              </div>
              <div class="meta-title align-self-center">
                <h6 class="title">Posted by <a href="#">Mohammad</a></h6>
              </div>
            </div>
          </div> <!-- single blog -->
        </div>
      </div> <!-- row -->
    </div> <!-- container -->
  </section>

  <!--====== BLOG PART ENDS ======-->
</template>

<script>
    export default {
        name: "Blog"
    }
</script>

<style scoped>

</style>
